#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argd, char*argv[]) {
    //printf(1, "hello world\n");
    hello(); //J.H.
}

